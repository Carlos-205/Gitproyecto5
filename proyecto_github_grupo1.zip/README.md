# Guía: Nuestro proyecto en GitHub

**Grupo:**

| Integrante | Rol asignado | Rama | Permiso |
|---|---|---|---|
| Juan Esteban Hernández Hurtado | **Líder** | `develop`, `main` | Owner / Admin |
| Jaider Cristóbal Marín | **Frontend** | `frontend` | Write |
| Luis Jerónimo Tapias Figero | **Backend** | `backend` | Write |
| Carlos Andrés Peña Peña | **Tester** | `testing` | Write |
| Alejandro Riaño | **Documentador** | `docs` | Write |

> Somos 5, uno por cada rol de la guía. Si prefieren otro reparto, cambien los nombres en `datos/equipo.json` y en el README.

---

## 0. Qué viene en este paquete

La carpeta `proyecto-equipo/` ya tiene **todos los archivos hechos**, con los nombres del grupo:

| Archivo | Lo sube | A la rama |
|---|---|---|
| `index.html`, `css/estilos.css`, `js/app.js` | Jaider (Frontend) | `frontend` |
| `datos/equipo.json` | Luis (Backend) | `backend` |
| `PRUEBAS.md` | Carlos (Tester) | `testing` |
| `README.md` | Alejandro (Documentador) | `docs` |
| `.github/CODEOWNERS` | Juan Esteban (Líder) | `develop` |

**Lo único que no se puede hacer desde aquí** son los pasos dentro de la página de GitHub (crear la organización, equipos, protecciones, etc.). Esos están abajo, en orden, con todos los comandos listos.

## 1. Cómo abrir el proyecto en tu computador

1. Instala [Git](https://git-scm.com/downloads) y [VS Code](https://code.visualstudio.com/).
2. En VS Code instala la extensión **Live Server** (icono de cuadritos › busca "Live Server" › Install).
3. Abre la carpeta `proyecto-equipo` en VS Code (**File › Open Folder**).
4. Clic derecho en `index.html` › **Open with Live Server**. Se abre el navegador con la página.

⚠️ **No abras `index.html` con doble clic**: el navegador bloquea la lectura de `datos/equipo.json` y verás un aviso en rojo.

## 2. Antes de empezar: llenar los datos que faltan

Busca y reemplaza estos textos (en VS Code: `Ctrl+Shift+H`, reemplazar en todos los archivos):

| Texto | Cámbialo por |
|---|---|
| `ORG` | El nombre de la organización que cree Juan Esteban (ej. `grupo1-poo-2026`) |
| `USUARIO-JUAN` | Usuario de GitHub de Juan Esteban |
| `USUARIO-JAIDER` | Usuario de GitHub de Jaider |
| `USUARIO-LUIS` | Usuario de GitHub de Luis |
| `USUARIO-CARLOS` | Usuario de GitHub de Carlos |
| `USUARIO-ALEJANDRO` | Usuario de GitHub de Alejandro |

Aparecen en `datos/equipo.json`, `README.md` y `.github/CODEOWNERS`. Revisen también que sus nombres estén bien escritos. Cada quien hace el reemplazo **solo en su archivo** y en su rama (para no generar conflictos).

---

## 3. Paso a paso (por orden)

### Paso 1 · Preparación — TODOS (10 min)

1. Crea tu cuenta en [github.com/signup](https://github.com/signup) si no tienes.
2. Activa la verificación en dos pasos: **Settings › Password and authentication**.
3. Envíale tu **usuario de GitHub** a Juan Esteban (el líder).
4. Configura Git:

```bash
git config --global user.name "Tu Nombre"
git config --global user.email "el-correo-de-tu-cuenta-github@correo.edu.co"
git config --global pull.rebase false
git --version
```

### Paso 2 · Organización — Juan Esteban (10 min)

1. En GitHub: botón **+** › **New organization** › plan **Free**. Nombre sin espacios, por ejemplo `grupo1-poo-2026`. Pertenece a **My personal account**.
2. En la organización: **People › Invite member**. Invita a Jaider, Luis, Carlos y Alejandro con rol **Member**.
3. **Jaider, Luis, Carlos y Alejandro:** acepten la invitación (llega al correo o en `https://github.com/orgs/ORG/invitation` › **Join**) y avisen a Juan Esteban.

### Paso 3 · Repositorio y ramas — Juan Esteban (10 min)

1. En la organización: **Repositories › New repository**. Owner: **la organización** (no tu usuario). Nombre `proyecto-equipo`, visibilidad **Public**, marca **Add a README file** y licencia **MIT License**.
2. Crea las ramas desde la terminal:

```bash
git clone https://github.com/ORG/proyecto-equipo.git
cd proyecto-equipo
git switch -c develop
git push -u origin develop
git switch -c frontend develop
git push -u origin frontend
git switch -c backend develop
git push -u origin backend
git switch -c testing develop
git push -u origin testing
git switch -c docs develop
git push -u origin docs
git switch develop
git branch -a
```

Debes ver seis ramas: `main`, `develop`, `frontend`, `backend`, `testing`, `docs`.

3. **Settings › General › Default branch** › ícono de flechas › `develop` › **Update**.

### Paso 4 · Equipos y permisos — Juan Esteban (15 min)

1. En la organización: **Teams › New team**. Crea cuatro equipos (visibilidad **Visible**): `frontend`, `backend`, `testing`, `docs`.
2. Con **Add a member** agrega a:
   - `frontend` → Jaider
   - `backend` → Luis
   - `testing` → Carlos
   - `docs` → Alejandro
3. En el repositorio: **Settings › Collaborators and teams › Add teams**. Agrega los 4 equipos con rol **Write**.
4. Agrega al docente: **Add people › `Jgigabot2` › rol Triage**.
5. Sube el archivo `.github/CODEOWNERS` a `develop` (copia el de este paquete, ya con `ORG` y tu usuario cambiados):

```bash
git switch develop
git add .github/CODEOWNERS
git commit -m "Define los revisores del proyecto"
git push
```

6. Protege las ramas: **Settings › Branches › Add classic branch protection rule**. Patrón `develop`, marca:
   - ✅ **Require a pull request before merging**
   - ✅ **Require approvals: 1**

   Guarda con **Create** y repite con el patrón `main`.

> ⚠️ Haz la protección **después** de subir CODEOWNERS (si no, GitHub no te deja hacer push directo a `develop`).

### Paso 5 · Organizar el trabajo — Alejandro (Documentador) (10 min)

1. **Etiquetas** (Issues › Labels › New label): `frontend`, `backend`, `testing`, `docs` (cada una con un color).
2. **Issues** (Issues › New issue), cada uno con su etiqueta y su asignado:

| # | Título | Etiqueta | Asignado |
|---|---|---|---|
| 1 | Crear la página principal del equipo | `frontend` | Jaider |
| 2 | Crear los datos del equipo en JSON | `backend` | Luis |
| 3 | Escribir los casos de prueba | `testing` | Carlos |
| 4 | Documentar el proyecto en el README | `docs` | Alejandro |

3. **Tablero**: en la organización **Projects › New project** › plantilla **Board**, nombre «Tablero del equipo». Con **Add item** agrega los 4 Issues (quedan en *Todo*).
4. **Todos:** arrastren su Issue a **In Progress**.

### Paso 6 · Trabajo en las ramas — cada uno en lo suyo (30 min)

Todos empiezan clonando el repo: `git clone https://github.com/ORG/proyecto-equipo.git` y `cd proyecto-equipo`.

#### Jaider (Frontend)

Copia `index.html`, `css/` y `js/` de este paquete dentro del repo clonado y ejecuta:

```bash
git switch frontend
git add .
git commit -m "Crea la página principal del equipo"
git push
```

En GitHub abre el Pull Request: base `develop` ← compare `frontend`. En la descripción escribe `Closes #1`.

#### Luis (Backend)

Copia `datos/equipo.json` (con los usuarios reales) y ejecuta:

```bash
git switch backend
git add .
git commit -m "Agrega los datos del equipo"
git push
```

Pull Request: base `develop` ← compare `backend`, descripción `Closes #2`. No cambies los nombres de los campos del JSON (es el contrato con frontend).

#### Carlos (Tester)

Copia `PRUEBAS.md` y ejecuta:

```bash
git switch testing
git add .
git commit -m "Agrega los casos de prueba"
git push
```

Pull Request: base `develop` ← compare `testing`, descripción `Closes #3`. Este PR lo revisa **Juan Esteban**.

#### Alejandro (Documentador)

Reemplaza el `README.md` del repo con el de `proyecto-equipo/README.md` y ejecuta:

```bash
git switch docs
git add .
git commit -m "Documenta el proyecto en el README"
git push
```

Pull Request: base `develop` ← compare `docs`, descripción `Closes #4`.

#### Revisar y aprobar los Pull Requests

- **Carlos** revisa y aprueba los PR de Jaider, Luis y Alejandro: abre el PR › **Files changed** › revisa línea por línea (puede comentar con el botón **+**) › **Review changes › Approve**.
- **Juan Esteban** aprueba el PR de Carlos (nadie puede aprobar su propio PR).
- Cuando esté aprobado, quien abrió el PR pulsa **Merge pull request › Confirm merge**.
- ❗ **No borren las ramas** de rol (ignoren el botón *Delete branch*).
- Muevan su Issue a **Done** en el tablero si no se movió solo.

### Paso 7 · Pruebas, release y publicación (20 min)

1. **Carlos** prueba el proyecto integrado:

```bash
git switch develop
git pull
```

   Abre `index.html` con Live Server y ejecuta los 7 casos de `PRUEBAS.md`. Si algo falla, abre un Issue con etiqueta `bug` y asígnalo.

2. **Juan Esteban** abre el release: Pull Request base `main` ← compare `develop`, título `Release v1.0.0`. Carlos lo aprueba y Juan Esteban lo integra.
3. **Juan Esteban** crea la versión: **Releases › Draft a new release › Choose a tag** › escribe `v1.0.0` › **Create new tag**. Target `main`, título «Versión 1.0.0». En la descripción lista lo que hizo cada rol › **Publish release**.
4. **Juan Esteban** publica la página: **Settings › Pages** › Source **Deploy from a branch** › Branch `main`, carpeta `/ (root)` › **Save**. En 1-2 minutos queda en:

```
https://ORG.github.io/proyecto-equipo/
```

5. **Carlos** ejecuta el caso 7 de las pruebas sobre esa dirección.

---

## 4. ✅ Lista de entrega (Juan Esteban sube los enlaces a Moodle)

- [ ] **Organización** con los 5 integrantes: `https://github.com/orgs/ORG/people`
- [ ] **Repositorio público** con README y licencia MIT: `https://github.com/ORG/proyecto-equipo`
- [ ] **Seis ramas** (main, develop, frontend, backend, testing, docs) con `develop` por defecto: `https://github.com/ORG/proyecto-equipo/branches`
- [ ] **Cuatro equipos** con permiso Write y el docente con Triage: `https://github.com/orgs/ORG/teams`
- [ ] **main y develop protegidas** + CODEOWNERS: captura de *Settings › Branches*
- [ ] **Issues con etiquetas** y **tablero** con todo en Done: `https://github.com/orgs/ORG/projects`
- [ ] **Cuatro Pull Requests** aprobados e integrados a develop + el PR de release a main: `https://github.com/ORG/proyecto-equipo/pulls?q=is%3Aclosed`
- [ ] **Release v1.0.0** y **página publicada**: `https://ORG.github.io/proyecto-equipo/`
- [ ] **Captura de Insights › Network** (muestra cómo se unieron las ramas)

## 5. Si se traban

| Problema | Solución |
|---|---|
| No puedo agregar a un compañero al equipo | Aún no aceptó la invitación: `https://github.com/orgs/ORG/invitation` |
| `Permission denied` / error 403 al hacer push | Su equipo no tiene permiso **Write** o no está en el equipo. Revisar *Settings › Collaborators and teams* |
| `protected branch hook declined` | Intentaron subir directo a `develop` o `main`. Cámbiense a su rama: `git switch frontend` (o la suya) |
| El botón Merge está gris («Review required») | Falta la aprobación. Carlos aprueba los PR de los demás y Juan Esteban el de Carlos |
| «No se encontró datos/equipo.json» | Usa **Live Server** (no doble clic). Si ya lo usas, el PR de backend aún no está en tu rama: `git switch develop` y `git pull` |
| El JSON da error | Casi siempre es una coma de más al final de una lista o comillas simples en vez de dobles. VS Code subraya el lugar |
| GitHub Pages da 404 | Espera 2 minutos y recarga. Verifica que el release a `main` ya esté integrado |
| `Need to specify how to reconcile divergent branches` | Ejecuta `git config --global pull.rebase false` y repite `git pull` |
